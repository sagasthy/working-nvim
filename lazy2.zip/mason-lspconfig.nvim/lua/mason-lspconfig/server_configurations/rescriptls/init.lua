return function()
    return {
        cmd = { "rescript-lsp", "--stdio" },
    }
end
