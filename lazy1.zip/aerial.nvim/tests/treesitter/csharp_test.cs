public class Cl_1 {
  public Cl_1() {}
  public void meth_1() {}
  public int Pr_1 {get;}
  public int Fl_1;
}
public enum En_1 { }
public struct St_1 { }
