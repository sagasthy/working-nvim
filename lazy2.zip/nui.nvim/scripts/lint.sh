#!/usr/bin/env sh

luacheck $@ .
