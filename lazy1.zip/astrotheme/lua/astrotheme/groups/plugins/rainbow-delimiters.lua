local function callback()
  return {
    RainbowDelimiterRed = { fg = C.syntax.red },
    RainbowDelimiterYellow = { fg = C.syntax.yellow },
    RainbowDelimiterBlue = { fg = C.syntax.blue },
    RainbowDelimiterOrange = { fg = C.syntax.orange },
    RainbowDelimiterGreen = { fg = C.syntax.green },
    RainbowDelimiterViolet = { fg = C.syntax.purple },
    RainbowDelimiterCyan = { fg = C.syntax.cyan },
  }
end

return callback
