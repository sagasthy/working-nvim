object Object {
  def foo(x: Int): Int = {
    ???
  }
}

trait Trait {
  def foo(x: Int): Unit
}

class Class {
  def foo(x: Int): Unit = {
    ???
  }
  def bar(x: Int): Unit = {
    ???
  }
}
