return function()
    return {
        cmd = { "perlnavigator", "--stdio" },
    }
end
