return {
	type = 'executable',
	command = vim.fn.exepath('chrome-debug-adapter'),
}
