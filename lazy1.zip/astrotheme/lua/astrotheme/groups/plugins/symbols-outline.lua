local function callback() return { FocusedSymbol = { fg = C.ui.yellow, bg = C.none } } end

return callback
