return {
	type = 'executable',
	command = vim.fn.exepath('haskell-debug-adapter'),
}
