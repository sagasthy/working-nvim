vim.opt.swapfile = false
vim.opt.rtp:append({ ".", vim.fn.stdpath("share") .. "/lazy/plenary.nvim" })
