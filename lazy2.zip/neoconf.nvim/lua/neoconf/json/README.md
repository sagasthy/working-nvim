# json library

This directory contains a pure lua json library from https://github.com/actboy168/json.lua
