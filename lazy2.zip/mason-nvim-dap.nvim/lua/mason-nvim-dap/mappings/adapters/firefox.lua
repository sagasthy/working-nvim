return {
	type = 'executable',
	command = vim.fn.exepath('firefox-debug-adapter'),
}
