---@class vim.api
vim.api = {}
