-- this is a test to see what i like
local function callback()
  return {
    FlashBackdrop = { fg = C.syntax.mute },
    FlashLabel = { fg = C.ui.base, bg = C.ui.orange, bold = true },
  }
end

return callback()
