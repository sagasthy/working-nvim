package main

func fn_1() {}

type st_1 struct{}

func (st_1) Meth_1() {}

type MyInterface interface{}
