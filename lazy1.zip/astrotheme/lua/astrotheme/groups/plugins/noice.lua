local function callback()
  return {
    NoiceCursor = { link = "Cursor" },
  }
end

return callback
