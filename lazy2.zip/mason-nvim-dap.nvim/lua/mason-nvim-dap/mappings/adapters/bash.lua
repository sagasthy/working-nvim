return {
	type = 'executable',
	command = vim.fn.exepath('bash-debug-adapter'),
}
