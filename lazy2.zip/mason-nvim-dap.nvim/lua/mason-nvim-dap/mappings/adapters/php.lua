return {
	type = 'executable',
	command = vim.fn.exepath('php-debug-adapter'),
}
