return {
	type = 'executable',
	command = vim.fn.exepath('node-debug2-adapter'),
}
