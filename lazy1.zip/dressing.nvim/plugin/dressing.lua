require("dressing").patch()
vim.cmd([[highlight default link FloatTitle FloatBorder]])
