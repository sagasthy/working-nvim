local function callback() return { Beacon = { bg = C.syntax.blue } } end

return callback
