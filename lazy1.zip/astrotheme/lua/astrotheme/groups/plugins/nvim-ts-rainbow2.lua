local function callback()
  return {
    TSRainbowRed = { fg = C.syntax.red },
    TSRainbowYellow = { fg = C.syntax.yellow },
    TSRainbowBlue = { fg = C.syntax.blue },
    TSRainbowOrange = { fg = C.syntax.orange },
    TSRainbowGreen = { fg = C.syntax.green },
    TSRainbowViolet = { fg = C.syntax.purple },
    TSRainbowCyan = { fg = C.syntax.cyan },
  }
end

return callback
