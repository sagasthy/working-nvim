local function callback()
  return {
    WindowPickerStatusLine = { fg = C.ui.red, bg = C.none },
    WindowPickerStatusLineNC = { fg = C.ui.red, bg = C.none },
    WindowPickerWinBar = { fg = C.ui.red, bg = C.none },
    WindowPickerWinBarNC = { fg = C.ui.red, bg = C.none },
  }
end

return callback
